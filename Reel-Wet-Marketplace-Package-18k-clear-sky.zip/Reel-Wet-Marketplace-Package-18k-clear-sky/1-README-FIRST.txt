REEL WET - MARKETPLACE POSTING GUIDE (for Jamie)
==================================================

PRICE DROP UPDATE (the listing is already live)
-----------------------------------------------
Edit the existing listing. Don't delete it and repost: editing keeps
everyone who saved it, and Facebook tells them the price dropped.

1. Open the Reel Wet listing from your Marketplace listings and tap Edit.

2. TITLE (copy exactly):
   19' 2000 North River Custom Jet Boat "Reel Wet" - Mercury Sport Jet 175

3. PRICE: 18000

4. DESCRIPTION: select everything in the box, delete it, then paste
   the whole "2-LISTING-DESCRIPTION-paste-this.txt" file.

5. PHOTOS: remove the old cover card and specs card (they say $25,000).
   Add the new 02-cover-card.jpg and 03-specs-card.jpg from the
   "photos-upload-in-order" folder and drag them into spots 2 and 3.

6. Tap Update. Done.


NEW LISTING (only if posting from scratch)
------------------------------------------
1. Open Facebook > Marketplace > Create new listing > Item for sale

2. PHOTOS: Upload everything in the "photos-upload-in-order" folder,
   in numbered order (01 first). 18 photos total, all pre-sized for FB.

3. TITLE (copy exactly):
   19' 2000 North River Custom Jet Boat "Reel Wet" - Mercury Sport Jet 175

4. PRICE: 18000

5. CATEGORY: Vehicles > Boats

6. CONDITION: Used - Good

7. DESCRIPTION: Open "2-LISTING-DESCRIPTION-paste-this.txt"
   and paste the whole thing into the description box.
   (Contact info in it is Justin's: (541) 659-3988 / jdietz18@gmail.com)

8. LOCATION: Grants Pass, OR

9. Hit Publish. Done.

EXTRAS folder: PDF flyer for emailing/printing, and an HTML web ad
to text or email to serious buyers.
